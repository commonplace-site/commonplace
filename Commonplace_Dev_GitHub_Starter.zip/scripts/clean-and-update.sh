
#!/bin/bash

# Navigate to project root
cd "$(dirname "$0")/.."

# Remove outdated files from public
rm -f public/Commonplace_Developer_*.pdf
rm -f public/*diagram*.png

# Copy new files into public
cp path/to/generated/Commonplace_Developer_Full_Guide_Complete.pdf public/
cp path/to/generated/system_diagram_img.png public/
cp path/to/generated/api_diagram_img.png public/

echo "✅ Developer files updated in /public."
