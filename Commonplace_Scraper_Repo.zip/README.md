# Commonplace Scraper Repository

## Description
This repository powers the data ingestion pipeline for Commonplace. It scrapes high-quality Chinese-language media sources, structures them into JSON or SQL format, and supports adaptive i+1 content delivery across various modules (i+1 Media, Radio, Language Test, etc).

## Folder Structure

```
commonplace-scraper/
├── output/                     # Saved JSON outputs
├── 8_Starter_Scraper.py       # VOA Chinese scraper
├── 9_Wikipedia_Scraper.py     # Wikipedia Chinese scraper
├── 10_TED_Chinese_Scraper.py  # TED 中文 transcript scraper
├── 11_Bilibili_Metadata_Scraper.py  # Bilibili title/desc only
├── 12_DW_Chinese_Scraper.py   # DW Chinese news scraper
├── 13_GPT_Post_Processing.py  # GPT summarization/tagging scaffold
├── 14_Google_Maps_Metadata_Scraper.py  # Basic location metadata
├── 15_CLI_Scraper_Tool.py     # Unified CLI runner for all scrapers
├── 16_Export_to_SQLite.py     # Local SQLite DB export
├── 3_Sample_JSON.json         # Example output format
├── README.md
└── requirements.txt           # Dependencies
```

## Getting Started

1. Clone the repo:
```bash
git clone https://github.com/YOUR_ORG/commonplace-scraper.git
cd commonplace-scraper
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run a test scraper:
```bash
python 8_Starter_Scraper.py
```

4. Use CLI runner:
```bash
python 15_CLI_Scraper_Tool.py voa https://www.voachinese.com/a/sample-url/
```

5. Export to SQLite:
```bash
python 16_Export_to_SQLite.py output/voa_YYYYMMDD_HHMMSS.json
```

## Dependencies
```
requests
beautifulsoup4
openai
sqlite3
```

## Notes
- GPT tagging requires an API key (set via environment variable or directly in script)
- Google Maps data is limited to metadata only (JS-heavy pages)
- Ethical scraping guidelines are documented in `6_Ethical_Scraping_Guide.txt`

## License
MIT (or specify your license)

## Authors
- Lead Scraper Dev: Jayson
- Maintainer: Jae Mong
