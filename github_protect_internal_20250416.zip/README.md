# 🔒 Internal Use Only

This repository includes internal design files and project memory folders for Commonplace.

## Restricted Folders
- `/docs/adversaria/`
- `/docs/room_127/`
- `/docs/codex/`
- `/internal/`

These are not for developer access and are excluded from all production branches and deploys.

Please do not modify or include these folders in pull requests.
